#include "basic_utils.h"

void logMsg(std::string msg) {
	std::cerr << msg << '\n';
}